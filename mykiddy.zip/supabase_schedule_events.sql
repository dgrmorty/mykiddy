-- ============================================
-- РАСПИСАНИЕ: события по дням недели (админ добавляет в админ-панели)
-- Выполните в Supabase → SQL Editor
-- ============================================

CREATE TABLE IF NOT EXISTS schedule_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  day_of_week INTEGER NOT NULL CHECK (day_of_week >= 1 AND day_of_week <= 7), -- 1=Пн ... 7=Вс
  time_start TEXT NOT NULL,  -- например "17:00"
  time_end TEXT,             -- например "18:30"
  title TEXT NOT NULL,
  description TEXT,
  location TEXT,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS schedule_events_day_idx ON schedule_events(day_of_week);

ALTER TABLE schedule_events ENABLE ROW LEVEL SECURITY;

-- Все аутентифицированные видят события
CREATE POLICY "Authenticated can read schedule_events"
  ON schedule_events FOR SELECT
  USING (auth.role() = 'authenticated');

-- Только админ может добавлять/редактировать/удалять
CREATE POLICY "Admin can insert schedule_events"
  ON schedule_events FOR INSERT
  WITH CHECK (public.is_admin_user());

CREATE POLICY "Admin can update schedule_events"
  ON schedule_events FOR UPDATE
  USING (public.is_admin_user());

CREATE POLICY "Admin can delete schedule_events"
  ON schedule_events FOR DELETE
  USING (public.is_admin_user());

-- ============================================
-- Готово. В админ-панели можно добавить вкладку «Расписание».
-- ============================================
